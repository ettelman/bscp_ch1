import base64
import os
import secrets
import sqlite3
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from urllib.parse import urlsplit

from flask import Flask, abort, redirect, render_template, request, url_for
from playwright.sync_api import sync_playwright

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "local-training-only-secret")
DB_PATH = "/tmp/blind-bscp.sqlite3"
PORTAL_COOKIE = "portal_session"
PORTAL_TOKEN = secrets.token_urlsafe(24)
ADMIN_COOKIE = "admin_session"
ADMIN_TOKEN = secrets.token_urlsafe(32)
ADMIN_USERNAME = "admin@northstar.test"
ADMIN_PASSWORD = secrets.token_urlsafe(12)
ADMIN_PASSWORD_B64 = base64.b64encode(ADMIN_PASSWORD.encode("utf-8")).decode("ascii")
lock = threading.Lock()
review_slot = threading.Semaphore(1)
review_workers = ThreadPoolExecutor(max_workers=1, thread_name_prefix="reviewer")
deliveries = []
bot_events = []


def bot_event(ticket_id, step, detail=""):
    event = {
        "time": datetime.now(timezone.utc).strftime("%H:%M:%S UTC"),
        "ticket_id": ticket_id,
        "step": step,
        "detail": detail[:3000],
    }
    with lock:
        bot_events.append(event)
        del bot_events[:-200]


def db():
    conn = sqlite3.connect(DB_PATH)
    # Keep SQLite's generous defaults from allowing sqlmap's large RANDOMBLOB probes
    # to allocate hundreds of megabytes inside the intentionally injectable query.
    conn.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 2 * 1024 * 1024)
    conn.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, 64 * 1024)
    conn.setlimit(sqlite3.SQLITE_LIMIT_LIKE_PATTERN_LENGTH, 1024)
    conn.row_factory = sqlite3.Row
    return conn


def initialize():
    conn = db()
    existing = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'feedback'"
    ).fetchone()
    if existing:
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(feedback)")}
        if "url" not in columns:
            # This lab has no durable submissions; recreate the old demo table schema.
            conn.execute("DROP TABLE feedback")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            plan TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        );
        DROP TABLE IF EXISTS integrations;
        DELETE FROM feedback;
        INSERT OR IGNORE INTO customers VALUES
            (1, 'Asterion Labs', 'ops@asterion.test', 'Enterprise'),
            (2, 'Northstar Freight', 'it@northstar.test', 'Business'),
            (3, 'Copperfield Systems', 'admin@copperfield.test', 'Enterprise');
    """)
    conn.execute(
        "INSERT OR REPLACE INTO users (id, username, password, role) VALUES (?, ?, ?, ?)",
        (1, ADMIN_USERNAME, ADMIN_PASSWORD_B64, "admin"),
    )
    conn.commit()
    conn.close()


def portal_required():
    if request.cookies.get(PORTAL_COOKIE) != PORTAL_TOKEN:
        abort(401)


@app.context_processor
def navigation_state():
    return {
        "is_portal_user": request.cookies.get(PORTAL_COOKIE) == PORTAL_TOKEN,
        "is_admin": request.cookies.get(ADMIN_COOKIE) == ADMIN_TOKEN,
    }


def admin_required():
    if request.cookies.get(ADMIN_COOKIE) != ADMIN_TOKEN:
        abort(401)


def review_in_browser(ticket_id):
    bot_event(ticket_id, "Browser job started")
    with review_slot:
        bot_event(ticket_id, "Browser slot acquired")
        browser = None
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(
                    executable_path="/usr/bin/chromium",
                    headless=True,
                    args=[
                        "--no-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-background-networking",
                        "--disable-extensions",
                        "--disable-sync",
                        "--no-first-run",
                        "--renderer-process-limit=2",
                    ],
                )
                bot_event(ticket_id, "Chromium launched")
                bot_event(ticket_id, "Creating browser context")
                context = browser.new_context()
                bot_event(ticket_id, "Browser context created")
                bot_event(ticket_id, "Setting staff cookie")
                context.add_cookies([{
                    "name": PORTAL_COOKIE,
                    "value": PORTAL_TOKEN,
                    "url": "http://127.0.0.1:5000",
                    "httpOnly": False,
                    "sameSite": "Lax",
                }])
                bot_event(ticket_id, "Staff cookie set")
                bot_event(ticket_id, "Creating browser page")
                page = context.new_page()
                bot_event(ticket_id, "Browser page created")
                page.on("request", lambda req: _log_external_request(ticket_id, req.url))
                page.on("response", lambda response: _log_external_response(ticket_id, response.url, response.status))
                page.on("requestfailed", lambda req: _log_failed_request(ticket_id, req.url, req.failure))
                page.on("pageerror", lambda _err: bot_event(ticket_id, "Page JavaScript error"))
                page.on("console", lambda msg: bot_event(ticket_id, "Browser console error") if msg.type == "error" else None)
                response = page.goto(f"http://127.0.0.1:5000/review/{ticket_id}", wait_until="domcontentloaded", timeout=10000)
                bot_event(ticket_id, "Review page loaded", f"HTTP {response.status if response else 'no response'}")
                cookie_readable = page.evaluate("document.cookie.includes('portal_session=')")
                bot_event(ticket_id, "Portal cookie readable by page JavaScript", str(cookie_readable).lower())
                target = page.locator("a[data-review-target]").get_attribute("href", timeout=5000)
                if target:
                    bot_event(ticket_id, "Review link extracted", target)
                else:
                    bot_event(ticket_id, "Review link missing")
                if target:
                    response = page.goto(f"http://127.0.0.1:5000{target}", wait_until="domcontentloaded", timeout=10000)
                    bot_event(ticket_id, "Target page loaded", f"HTTP {response.status if response else 'no response'}")
                    page.wait_for_timeout(3000)
                    state = page.evaluate("document.readyState")
                    bot_event(ticket_id, "Target page settled", f"readyState={state}")
                    rendered = page.locator("#resource-view").evaluate("el => el.innerHTML")
                    bot_event(ticket_id, "Rendered preview HTML", rendered)
                browser.close()
                browser = None
                bot_event(ticket_id, "Browser closed")
        except Exception as exc:
            app.logger.exception("Review browser failed for ticket %s", ticket_id)
            bot_event(ticket_id, "Browser error", str(exc))
        finally:
            if browser is not None:
                try:
                    if browser.is_connected():
                        browser.close()
                except Exception:
                    app.logger.exception("Could not close review browser for ticket %s", ticket_id)


def _log_external_request(ticket_id, url):
    host = urlsplit(url).hostname or "unknown host"
    if host not in {"127.0.0.1", "localhost"}:
        bot_event(ticket_id, "External request", host)


def _log_failed_request(ticket_id, url, failure):
    host = urlsplit(url).hostname or "unknown host"
    if host not in {"127.0.0.1", "localhost"}:
        bot_event(ticket_id, "External request failed", f"{host}: {failure or 'unknown reason'}")


def _log_external_response(ticket_id, url, status):
    host = urlsplit(url).hostname or "unknown host"
    if host not in {"127.0.0.1", "localhost"}:
        bot_event(ticket_id, "External response", f"{host}: HTTP {status}")


@app.get("/")
def home():
    return render_template("home.html")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.route("/feedback", methods=["GET", "POST"])
def feedback():
    if request.method == "POST":
        name = request.form.get("name", "")[:120]
        target = request.form.get("url", "")[:1800].strip()
        if not name or not target:
            return render_template("feedback.html", error="Please complete both fields."), 400
        # The review system only accepts same-origin paths, never external URLs.
        if not target.startswith("/") or target.startswith("//") or "\\" in target:
            return render_template("feedback.html", error="Enter a link from this portal, beginning with /."), 400
        conn = db()
        cursor = conn.execute(
            "INSERT INTO feedback (name, url, created_at) VALUES (?, ?, ?)",
            (name, target, datetime.now(timezone.utc).isoformat()),
        )
        ticket_id = cursor.lastrowid
        conn.commit()
        conn.close()
        bot_event(ticket_id, "Review request queued", "Waiting for support browser")
        review_workers.submit(review_in_browser, ticket_id)
        return render_template("feedback.html", submitted=True, ticket_id=ticket_id)
    return render_template("feedback.html")


@app.get("/review/<int:ticket_id>")
def review(ticket_id):
    portal_required()
    conn = db()
    row = conn.execute("SELECT * FROM feedback WHERE id = ?", (ticket_id,)).fetchone()
    conn.close()
    if row is None:
        abort(404)
    # Deliberately unsafe: staff review renders submitted content as HTML.
    return render_template("review.html", ticket=row)


@app.get("/resources")
def resources():
    return render_template("resources.html")


@app.route("/account-lookup", methods=["GET", "POST"])
def account_lookup():
    portal_required()
    rows = None
    error = None
    if request.method == "POST":
        search = request.form.get("q", "")
        # Deliberately unsafe SQL concatenation for the training exercise.
        sql = f"SELECT id, name, email FROM customers WHERE name LIKE '%{search}%' LIMIT 25"
        conn = db()
        try:
            rows = conn.execute(sql).fetchall()
        except sqlite3.Error as exc:
            error = str(exc)
        finally:
            conn.close()
    return render_template("staff.html", rows=rows, error=error)


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    portal_required()
    if request.cookies.get(ADMIN_COOKIE) == ADMIN_TOKEN:
        return redirect(url_for("diagnostics"))
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")[:200]
        password = request.form.get("password", "")[:200]
        password_b64 = base64.b64encode(password.encode("utf-8")).decode("ascii")
        conn = db()
        row = conn.execute(
            "SELECT id FROM users WHERE username = ? AND password = ? AND role = 'admin'",
            (username, password_b64),
        ).fetchone()
        conn.close()
        if row:
            response = redirect(url_for("diagnostics"))
            response.set_cookie(
                ADMIN_COOKIE, ADMIN_TOKEN, httponly=True,
                secure=request.is_secure, samesite="Lax", path="/",
            )
            return response
        error = "The username or password was not accepted."
    return render_template("admin_login.html", error=error)


@app.get("/admin/logout")
def admin_logout():
    portal_required()
    response = redirect(url_for("account_lookup"))
    response.delete_cookie(ADMIN_COOKIE, path="/")
    return response


@app.route("/operations/diagnostics", methods=["GET", "POST"])
def diagnostics():
    admin_required()
    output = None
    error = None
    if request.method == "POST":
        host = request.form.get("host", "")[:300]
        if not host:
            error = "Enter a host name."
        elif (
            any(char in host for char in (" ", "\t", "\r", ";", "|", "&", "`"))
            or "$(" in host
        ):
            error = "The host contains unsupported characters."
        else:
            # Deliberately unsafe shell invocation with a weak character filter,
            # confined to this training container.
            import subprocess
            try:
                result = subprocess.run(
                    f"getent hosts {host}", shell=True, capture_output=True,
                    text=True, timeout=10, cwd="/tmp", env={"PATH": "/usr/bin:/bin"},
                )
                output = (result.stdout + result.stderr)[:12000]
            except subprocess.TimeoutExpired:
                error = "The lookup took too long."
    return render_template("diagnostics.html", output=output, error=error)


@app.get("/collect")
def collect():
    record = {
        "time": datetime.now(timezone.utc).strftime("%H:%M:%S UTC"),
        "query": request.query_string.decode("utf-8", errors="replace")[:3000],
        "user_agent": request.headers.get("User-Agent", "")[:200],
    }
    with lock:
        deliveries.append(record)
        del deliveries[:-100]
    return "", 204


@app.get("/inbox")
def inbox():
    with lock:
        records = list(reversed(deliveries))
    return render_template("inbox.html", records=records)


@app.get("/__lab/bot-status")
def bot_status():
    if os.environ.get("LAB_DIAGNOSTICS", "0") != "1":
        abort(404)
    with lock:
        events = list(reversed(bot_events))
    return render_template("bot_status.html", events=events)


@app.get("/reset")
def reset():
    initialize()
    with lock:
        deliveries.clear()
    return redirect(url_for("home"))


initialize()


if __name__ == "__main__":
    # Keep direct local runs bounded too; Docker uses Gunicorn with a fixed thread pool.
    app.run(host="0.0.0.0", port=5000, threaded=False)
